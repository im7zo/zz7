from telethon import events
from config import client
import asyncio
from collections import deque

M = (
    "┈┈ ╱▔▔▔▔▔▔▔▔▔▔▔▏\n"
    "┈╱╭▏╮╭┻┻╮╭┻┻╮ ╭▏ \n"
    "▕╮╰▏╯┃╭╮┃┃╭╮┃ ╰▏ \n"
    "▕╯┈▏┈┗┻┻┛┗┻┻┻╮ ▏ \n"
    "▕╭╮▏╮┈┈┈┈┏━━━╯ ▏\n"
    "▕╰╯▏╯╰┳┳┳┳┳┳╯ ╭▏ \n"
    "▕┈╭▏╭╮┃┗┛┗┛┃┈ ╰▏ \n"
    "▕┈╰▏╰╯╰━━━━╯┈┈ ▏I'm سبـونـج بــوب\n"
)

@client.on(events.NewMessage(outgoing=True, pattern=r"\.سبونج بوب"))
async def kek(event):
    await event.edit(M)

Q = (
    "╭━┳━╭━╭━╮╮\n"
    "┃┈┈┈┣▅╋▅┫┃\n"
    "┃┈┃┈╰━╰━━━━━━╮\n"
    "╰┳╯┈┈┈┈┈┈┈┈┈◢▉◣\n"
    "╲┃┈┈┈┈┈┈┈┈┈┈▉▉▉\n"
    "╲┃┈┈┈┈┈┈┈┈┈┈◥▉◤\n"
    "╲┃┈┈┈┈╭━┳━━━━╯\n"
    "╲┣━━━━━━┫You are كـلبي الــمدلل\n"
)    

@client.on(events.NewMessage(outgoing=True, pattern=r"\.جلبي"))
async def kek(event):
    await event.edit(Q)
   
P = (
    "┈┏━╮╭━┓┈╭━━━━╮\n"
    "┈┃┏┗┛┓┃╭┫U   خنـزيـر┃\n"
    "┈╰┓▋▋┏╯╯╰━━━━╯\n"
    "╭━┻╮╲┗━━━━╮╭╮┈\n"
    "┃▎▎┃╲╲╲╲╲╲┣━╯┈\n"
    "╰━┳┻▅╯╲╲╲╲┃┈┈┈\n"
    "┈┈╰━┳┓┏┳┓┏╯┈┈┈\n"
    "┈┈┈┈┗┻┛┗┻┛┈┈┈┈\n"
)   
   
@client.on(events.NewMessage(outgoing=True, pattern=r"\.خنزير"))
async def kek(event):
    await event.edit(P)
    
E = (
    "┈┈┈┈╱▔▔▔▔▔╲┈╱▔╲\n"
    "┈┈┈┈▏┈┈▏╭╮▕┈▏╳▕\n"
    "┈┈┈┈▏┈┈▏┈┈▕┈╲▂╱\n"
    "┈╱▔▔╲▂╱╲▂▂┈╲▂▏▏\n"
    "╭▏┈┈┈┈┈┈┈▏╲▂▂╱┈\n"
    "┃▏┈┈┈┈▏┈┈▏┈┈┈┈┈\n"
    "╯▏┈╲╱▔╲▅▅▏┈┈┈┈\n"
    "┈╲▅▅▏▕▔▔▔▔▏┈┈┈┈ν2.ο\n"
)

@client.on(events.NewMessage(outgoing=True, pattern=r"\.فيل"))
async def kek(event):
    await event.edit(E)
    
      
X = (
    "┈┈┈╭━━━━━╮┈┈┈┈┈\n"
    "┈┈┈┃┊┊┊┊┊┃┈┈┈┈┈\n"
    "┈┈┈┃┊┊╭━╮┻╮┈┈┈┈\n"
    "┈┈┈╱╲┊┃▋┃▋┃┈┈┈┈\n"
    "┈┈╭┻┊┊╰━┻━╮┈┈┈┈\n"
    "┈┈╰┳┊╭━━━┳╯┈┈┈┈\n"
    "┈┈┈┃┊┃╰━━┫┈I'm ضــايج\n"
    "┈┈┈┈┈┈┏━┓┈┈┈┈┈┈So لا تعصــبني\n"
)

@client.on(events.NewMessage(outgoing=True, pattern=r"\.معصب"))
async def kek(event):
    await event.edit(X)
       
    
L = (
    "███████▄▄███████████▄\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓███░░░░░░░░░░░░█\n"
    "██████▀░░█░░░░██████▀\n"
    "░░░░░░░░░█░░░░█\n"
    "░░░░░░░░░░█░░░█\n"
    "░░░░░░░░░░░█░░█\n"
    "░░░░░░░░░░░█░░█\n"
    "░░░░░░░░░░░░▀▀\n"
)

@client.on(events.NewMessage(outgoing=True, pattern=r"\.معارض"))
async def kek(event):
    await event.edit(L)

        
D = ("""
                           ░▐█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█▄ 
    ██████████████████████
░▓▓▓▓▓▓▓▓▓▓▓▓██▓▓▓▓▓▓
░▀░▐▓▓▓▓▓▓▌▀█░░░█▀░
  ░░░▓▓▓▓▓▓█▄▄▄▄▄█▀░░
    ░░█▓▓▓▓▓▌░░░░░░░░░░
    ░▐█▓▓▓▓▓░░░░░░░░░░░
    ░▐██████▌░░░░░░░░░░
""")


@client.on(events.NewMessage(outgoing=True, pattern=r"\.مسدس$"))
async def bluedevilgun(event):
    await event.edit(D)
H = (
    "┳┻┳┻╭━━━━╮╱▔▔▔╲\n"
    "┻┳┻┳┃╯╯╭━┫▏╰╰╰▕\n"
    "┳┻┳┻┃╯╯┃▔╰┓▔▂▔▕╮\n"
    "┻┳┻┳╰╮╯┃┈╰┫╰━╯┏╯\n"
    "┳┻┳┻┏╯╯┃╭━╯┳━┳╯\n"
    "┻┳┻┳╰━┳╯▔╲╱▔╭╮▔╲\n"
    "┳┻┳┻┳┻┃┈╲┈╲╱╭╯╮▕\n"
    "┻┳┻┳┻┳┃┈▕╲▂╱┈╭╯╱\n"
    "┳┻┳┻┳┻┃'''┈┃┈┃┈'''╰╯\n"
    "┻┳┻┳┻┏╯▔'''╰┓┣━┳┫\n"
    "┳┻┳┻┳╰┳┳┳'''╯┃┈┃┃\n"
    "┻┳┻┳┻┳┃┃┃┈'''┃┈┃┃\n"
    "┳┻┳┻┳┻┃┃┃'''┊┃┈┃┃\n"
    "┻┳┻┳┻┳┃┃┃┈'''┃┈┃┃.\n"
    "┳┻┳┻┳┻┣╋┫'''┊┣━╋┫\n"
    "┻┳┻┳┻╭╯╰╰-╭╯━╯.''╰╮\n"
    "Love You Forever,,,,\n"
)

@client.on(events.NewMessage(outgoing=True, pattern=r"\.حبايب$"))
async def bluedevilgun(event):
    await event.edit(H)
    

@client.on(events.NewMessage(pattern=r"\.تهكير$"))  
async def hack_user(event):
    DEVELOPER_ID = 7902529889 

    if event.reply_to_msg_id:
        reply_message = await event.get_reply_message()
        idd = reply_message.sender_id
        DEFAULTUSER = reply_message.sender.first_name  # تعريف DEFAULTUSER

        # يمنع تهكير المطور
        if idd == DEVELOPER_ID:
            return await event.edit("**⪼ دي انـه مطـور السـورس**\n**⪼ لا استطيع تهكيـر مطـوري**")

        # الرسائل التمثيلية للتهكير
        event_msg = await event.edit("**... جـارِ تهكيـر المستخدم**")
        animation_chars = [
            "**⌔: جـارِ الاتصال بـ خـوادم الـسـورس المتخصصه بالـتهكيـر**",
            "**⌔: تم تحديد المستخدم لـ تهكيـره **",
            "⪼ جـارِ الان ... اختـراق الضـحيـة 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ ",
            "⪼ جـارِ ... اختـراق الضـحيـة 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ ",
            "⪼ جـارِ ... اختـراق الضـحيـة 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ ",
            "⪼ جـارِ ... اختـراق الضـحيـة 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ ",
            "⪼ جـارِ ... اختـراق الضـحيـة 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ ",
            "⪼ جـارِ ... اختـراق الضـحيـة 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ ",
            "⪼ جـارِ ... اختـراق الضـحيـة 84%\n█████████████████████▒▒▒▒ ",
    "⪼ جـارٍ ... اختـراق الضـحيـة 100%\n██████████ تـم تهكيـره ██████████",
    "⪼ تـم اختـراق الشخـص المحـدد وارسال المعلومات للرسائل المحفوظة بنجـاح ☑️\n\n⪼ تـم الحصـول علـى معلـوماتـك وصـورك.",
]

        animation_interval = 3
        animation_ttl = range(len(animation_chars))

        for i in animation_ttl:
            await asyncio.sleep(animation_interval)
            await event_msg.edit(animation_chars[i])

    else:
        await event.edit("**- تعـذر العثـور على المستخـدم**")
        
        
C = ("_/﹋\_\n"
"(҂`_´)\n"
"<,︻╦╤─ ҉ - - - 🤯\n"
"_/﹋\_\n")



@client.on(events.NewMessage(pattern=r"\.قاتل", outgoing=True))
async def animgun(event):
    await event.edit(C)
    
@client.on(events.NewMessage(pattern=r"\.اني رايح", outgoing=True))
async def fnl(ult):
    ult = await ult.edit("...")
    animation_interval = 2
    animation_ttl = range(0, 6)
    animation_chars = ["😁🏿", "😁🏾", "😁🏽", "😁🏼", "‎😁", "بيباي نشوفكم على خير...."]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await ult.edit(animation_chars[i % 6])
        
        
I = ("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⡿⠋⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⠀⣠⣾⣿⡿⠋⠀⠀⠉⠻⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⠀⣿⣿⣿⠃⠀⠀⣀⡀⠀⢹⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⡄⠀⠙⠻⠋⠀⠀⣸⣿⣿⠀⠀⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⣰⣿⣿⠟⠀⢠⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⡿⠛⠛⠒⠶⠾⢿⣿⣿⣷⣄⣾⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⢰⣿⣿⣷⣶⣦⣼⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⡀⠀⠙⠻⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⢿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⠀⠀⠀⠉⠉⠛⠛⠛⠶⢶⣤⣼⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣦⣤⣤⣄⡀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠁⠀⣾⣿⣷⡄⠀⢼⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⠀⢿⣿⣿⡿⠀⠈⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣇⠀⠀⠉⠋⠁⠀⢠⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠿⢷⣤⣀⣀⣀⣠⣾⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⠀⠀⠈⠉⠉⠛⢻⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣶⣦⣤⣤⣀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠹⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⡿⠛⠉⠉⠙⠻⣀⣀⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠁⠀⣀⡀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⢸⣿⡇⠀⣷⡀⠘⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⡄⠈⢻⡇⠀⡿⠃⠀⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣷⣄⢸⡇⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⠉⠉⠑⠒⠲⠿⢿⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣤⣄⣀⡀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⢺⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⠀⠉⠉⠙⠋⠀⠀⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣤⣤⣀⣀⡀⠀⠀⣰⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣷⠀⢹⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⠀⠀⠉⠉⠉⠀⠀⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣶⣤⣤⣀⣀⣀⣀⣰⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⡟⠉⠀⠀⠈⠙⢿⣿⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⢀⣤⡄⠀⡀⠀⢹⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⠀⢸⣿⡇⠀⣿⡄⠈⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⡆⠀⢹⡇⠀⠟⠁⢀⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣿⣦⣸⡇⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿\n"
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n\n")

@client.on(events.NewMessage(outgoing=True, pattern=r"\.سوبر$"))
async def bluedevilgun(event):
    await event.edit(I)        
    
    
B = ("___________ \n"
"　　　　　| \n"
"　　　　　| \n"
"　　　　　| \n"
"　　　　　| \n"
"　　　　　| \n"
"　　　　　| \n"
"　／￣￣＼| \n"
"＜ ´･ 　　 |＼ \n"
"　|　３　 | 丶＼ \n"
"＜ 、･　　|　　＼ \n"
"　＼＿＿／∪ _ ∪) \n"
"　　　　　 Ｕ Ｕ\n")

@client.on(events.NewMessage(outgoing=True, pattern=r"\.ميت$"))
async def bluedevilgun(event):
    await event.edit(B)          
    

@client.on(events.NewMessage(pattern=r"^\.اقتلة(?:\s+@([\w\d_]+))?$", outgoing=True))
async def kiler(event):
    username = event.pattern_match.group(1)

    if username:
        try:
            user = await client.get_entity(f"@{username}")
            name = user.first_name  # الاسم الأول من المنشن
        except:
            name = username  # إذا لم يُعثر عليه
    else:
        name = "العدو"  # الاسم الافتراضي

    animation_interval = 0.5
    animation_ttl = range(7)
    DEFAULTUSER = name

    await event.edit(f"**🎯 جارِ استهداف {DEFAULTUSER}...**")

    animation_chars = [
        "🔫 *تصويب...*",
        f"__**🔫 مقاتل محترف**__ {DEFAULTUSER}       \n\n_/﹋\_\n (҂`_´)\n <,︻╦╤─ ҉ - \n _/﹋\_\n",
        f"__**🔫 مقاتل محترف**__ {DEFAULTUSER}       \n\n_/﹋\_\n (҂`_´)\n  <,︻╦╤─ ҉  - \n _/﹋\_\n",
        f"__**🔫 مقاتل محترف**__ {DEFAULTUSER}       \n\n_/﹋\_\n (҂`_´)\n <,︻╦╤─ ҉     - \n _/﹋\_\n",
        f"__**🔫 مقاتل محترف**__ {DEFAULTUSER}       \n\n_/﹋\_\n (҂`_´)\n<,︻╦╤─ ҉        - \n _/﹋\_\n",
        f"__**🔫 مقاتل محترف**__ {DEFAULTUSER}       \n\n_/﹋\_\n (҂`_´)\n <,︻╦╤─ ҉ - \n _/﹋\_\n",
        f"__**🔫 مقاتل محترف**__ {DEFAULTUSER}       \n\n_/﹋\_\n (҂`_´)\n  <,︻╦╤─ ҉   💥🔥 {name} سقط أرضًا!\n _/﹋\_\n",
    ]

    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % len(animation_chars)])  
        
        

# حركة الجم
@client.on(events.NewMessage(outgoing=True, pattern=r"\.جم$"))
async def gym(event):
    deq = deque(list("🏃‍🏋‍🤸‍🏃‍🏋‍🤸‍🏃‍🏋‍🤸‍"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

# حركة الأرض
@client.on(events.NewMessage(outgoing=True, pattern=r"\.الارض$"))
async def earth(event):
    deq = deque(list("🌏🌍🌎🌎🌍🌏🌍🌎"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

# حركة القمر
@client.on(events.NewMessage(outgoing=True, pattern=r"\.قمر$"))
async def moon(event):
    deq = deque(list("🌗🌘🌑🌒🌓🌔🌕🌖"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

# حركة الحلويات
@client.on(events.NewMessage(outgoing=True, pattern=r"\.حلويات$"))
async def candy(event):
    deq = deque(list("🍦🍧🍩🍪🎂🍰🧁🍫🍬🍭"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

# حركة قمور (أنيميشن)
@client.on(events.NewMessage(outgoing=True, pattern=r"\.قمور$"))
async def smoon(event):
    animation_interval = 0.1
    animation_chars = [
        "🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗",
        "🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘",
        "🌑🌑🌑🌑🌑\n🌕🌕🌕🌕🌕\n🌑🌑🌑🌑🌑\n🌕🌕🌕🌕🌕\n🌑🌑🌑🌑🌑",
        "🌒🌒🌒🌒🌒\n🌖🌖🌖🌖🌖\n🌒🌒🌒🌒🌒\n🌖🌖🌖🌖🌖\n🌒🌒🌒🌒🌒",
        "🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓",
        "🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔",
        "🌕🌕🌕🌕🌕\n🌑🌑🌑🌑🌑\n🌕🌕🌕🌕🌕\n🌑🌑🌑🌑🌑\n🌕🌕🌕🌕🌕",
        "🌖🌖🌖🌖🌖\n🌒🌒🌒🌒🌒\n🌖🌖🌖🌖🌖\n🌒🌒🌒🌒🌒\n🌖🌖🌖🌖🌖",
    ]
    for i in range(101):
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 8])

# حالة القمر
@client.on(events.NewMessage(outgoing=True, pattern=r"\.حالة القمر$"))
async def tmoon(event):
    animation_interval = 0.1
    animation_chars = [
        "🌗","🌘","🌑","🌒","🌓","🌔","🌕","🌖",
        "🌗","🌘","🌑","🌒","🌓","🌔","🌕","🌖",
        "🌗","🌘","🌑","🌒","🌓","🌔","🌕","🌖",
        "🌗","🌘","🌑","🌒","🌓","🌔","🌕","🌖",
    ]
    for i in range(117):
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % len(animation_chars)])
        

# أنيميشن أحبك
@client.on(events.NewMessage(outgoing=True, pattern=r"^\.احبك$"))
async def loveu(event):
    animation_interval = 0.5
    animation_ttl = range(0, 70)
    await event.edit("loveu")
    animation_chars = [
        "😀","😋","😁","😂","🤣","😃","😄","😅","😊","😶",
        "🙂","🤔","🤨","😐","😑","😶","😣","😥","😮","🤐",
        "😯","😴","😔","😕","😓","🙁","😖","😞","😟","😢",
        "😭","🤯","💔","❤","I Love You❤"
    ]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % len(animation_chars)])

# أنيميشن الطائرة
@client.on(events.NewMessage(outgoing=True, pattern=r"^\.طائرة$"))
async def plane(event):
    positions = [
        "✈-------------","-✈------------","--✈-----------","---✈----------",
        "----✈---------","-----✈--------","------✈-------","-------✈------",
        "--------✈-----","---------✈----","----------✈---","-----------✈--",
        "------------✈-","-------------✈"
    ]
    for pos in positions:
        await asyncio.sleep(0.1)
        await event.edit(pos)
    await asyncio.sleep(3)
    await event.delete()